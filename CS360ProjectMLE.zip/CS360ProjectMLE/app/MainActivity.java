import android.Manifest;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.telephony.SmsManager;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;
    private EditText editDate, editWeight;
    private Button btnAddData, btnSendSMS;
    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();

        editDate = findViewById(R.id.editTextDate);
        editWeight = findViewById(R.id.editTextWeight);
        btnAddData = findViewById(R.id.buttonAddData);
        btnSendSMS = findViewById(R.id.buttonSendSMS);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyAdapter(getData(), this);
        recyclerView.setAdapter(adapter);

        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
                adapter.updateData(getData());
            }
        });

        btnSendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Request SMS permissions
                requestSmsPermissions();
            }
        });
    }

    private void insertData() {
        String date = editDate.getText().toString();
        double weight = Double.parseDouble(editWeight.getText().toString());

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_DATE, date);
        values.put(DatabaseHelper.COLUMN_WEIGHT, weight);

        long newRowId = database.insert(DatabaseHelper.TABLE_NAME, null, values);

        editDate.setText("");
        editWeight.setText("");
    }

    private Cursor getData() {
        String[] columns = {DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_DATE, DatabaseHelper.COLUMN_WEIGHT};
        return database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
    }

    private void requestSmsPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            sendSmsMessage();
        }
    }

    private void sendSmsMessage() {
        String phoneNumber = "1234567890"; // Replace with the recipient's phone number
        String message = "Hello, this is your weight tracking app notification.";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

        Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_PERMISSIONS_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can now send SMS
                sendSmsMessage();
            } else {
                // Permission denied, handle it accordingly
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
